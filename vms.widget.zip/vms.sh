#!/bin/bash
#
vm=`/Applications/VMware\ Fusion.app/Contents/Library/vmrun -T fusion list |awk -F/ '{print $NF}'|sed s/.vmx//g|grep -v Total|sed 'N;s/\n/ | /' `
pa=`/usr/local/bin/prlctl list -a --vmtype vm|grep -v NAME|grep  running|awk '{ $1=""; $2=""; $3=""; print}'| sed -e 's/^[ \t]*//'`
vb=`/usr/local/bin/VBoxManage list runningvms|awk '{print $1}'|sed 's/ //g'|sed 'N;s/\n/ | /' `
vmcount=`/Applications/VMware\ Fusion.app/Contents/Library/vmrun -T fusion list |head -1|awk '{print $4}'`
pacount=`ps -ef |grep Parallel|grep Window|head -1|wc -l`
vbcount=`/usr/local/bin/VBoxManage list runningvms|wc -l`
#

total=$(( $vmcount + $pacount + $vbcount ))
echo  -e "Running VM Count = $total  "
echo ""
if [ $total -ne 0 ];then

echo -e  " Fusion: \t $vm  "
echo -e  " Parallels: \t $pa  "
echo -e  " VBox: \t $vb  "

fi
